/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inacap.webcomponent.prueba4.Controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import inacap.webcomponent.prueba4.Model.DevolucionModel;
import inacap.webcomponent.prueba4.Repository.DevolucionRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
/**
 *
 * @author Rodrigo
 */
  @RestController
@RequestMapping("/url")
public class DevolucionController {
  
    @Autowired
    private DevolucionRepository DevolucionRepository;

    @GetMapping()
    public Iterable<DevolucionModel> listarTodos() {

        return DevolucionRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DevolucionModel> muestraDevolucion(@PathVariable String id) {

        Optional<DevolucionModel> mOptional = DevolucionRepository.findById(Integer.parseInt(id));

        if (mOptional.isPresent()) {
            return new ResponseEntity(mOptional.get(), HttpStatus.FOUND);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<DevolucionModel> editarmarca(@PathVariable String id, @RequestBody DevolucionModel devolucioneditar) {

        Optional<DevolucionModel> cOptional = DevolucionRepository.findById(Integer.parseInt(id));

        if (cOptional.isPresent()) {
            
            DevolucionModel mEncontrado = cOptional.get();
            devolucioneditar.setIdDevolucion(mEncontrado.getIdDevolucion());
            return new ResponseEntity(devolucioneditar, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_MODIFIED);
        }

    }

    @PostMapping
    public ResponseEntity<?> agregardevolucion(@RequestBody DevolucionModel nuevadevolucion) {
        
        nuevadevolucion = DevolucionRepository.save(nuevadevolucion);
        
        Optional<DevolucionModel>mOptional = DevolucionRepository.findById(nuevadevolucion.getIdDevolucion());
        
        if(mOptional.isPresent()){
            return new ResponseEntity(mOptional.get(), HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable String id) {
        
        Optional<DevolucionModel> mOptional = DevolucionRepository.findById(Integer.parseInt(id));

        if (mOptional.isPresent()) {
            
            DevolucionRepository.deleteById(Integer.parseInt(id));
            return new ResponseEntity(mOptional.get(), HttpStatus.OK);
            
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

}


